import { Component, OnInit } from '@angular/core';
import { OdometerService } from '../odometer.service';

@Component({
  selector: 'app-odometer',
  templateUrl: './odometer.component.html',
  styleUrls: ['./odometer.component.css']
})
export class OdometerComponent implements OnInit {
  reading: number | undefined;
  userReading: number | undefined;

  constructor(private odometerService: OdometerService) { }

  ngOnInit() {
    this.reading = this.odometerService.getReading();
  }

  updateReading(): void {
    try {
      if (this.userReading !== undefined) {
        if(this.isAscending(this.userReading)){
          this.odometerService.setReading(this.userReading);
          this.odometerService.reset(this.userReading); 
          this.reading = this.userReading;
        }
        else{
          alert("Enter a reading with digits in strictly ascending order.")
        }
      }
    } catch (error) {
      console.error((error as Error).message); 
    }
  }

  increment() {
    this.odometerService.increment();
    this.reading = this.odometerService.getReading();
  }

  decrement() {
    this.odometerService.decrementReading();
    this.reading = this.odometerService.getReading();
  }

  reset() {
    if (this.userReading !== undefined) {
      this.odometerService.reset(this.userReading); 
      this.reading = this.userReading; 
    }
  }
  private isAscending(reading: number): boolean {
    if (reading < 10) {
      return true;
    }
    if (reading % 10 <= Math.floor(reading / 10) % 10) {
      return false;
    }
    return this.isAscending(Math.floor(reading / 10));
  }
  
}
