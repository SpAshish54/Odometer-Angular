import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class OdometerService {
  private reading: number = 0;

  constructor() {
    this.reading = 123; 
  }

  getReading(): number {
    return this.reading;
  }

  setReading(reading: number): void {
    this.reading = reading;
  }

  increment(): void {
    do {
      if (this.reading === this.getMaxReading(this.getSize(this.reading))) {
        this.reading = this.getMinReading(this.getSize(this.reading));
      } else {
        this.reading++;
      }
    } while (!this.isAscending(this.reading));
  }

  decrementReading(): void {
    do {
      if (this.reading === this.getMinReading(this.getSize(this.reading))) {
        this.reading = this.getMaxReading(this.getSize(this.reading));
      } else {
        this.reading--;
      }
    } while (!this.isAscending(this.reading));
  }

  reset(userReading: number): void {
    if (userReading !== undefined) {
      this.reading = userReading;
    }
  }
  

  private getMinReading(size: number): number {
    return parseInt('1'.repeat(size));
  }

  private getMaxReading(size: number): number {
    return parseInt('9'.repeat(size));
  }

  private getSize(reading: number): number {
    return reading.toString().length;
  }

  private isAscending(reading: number): boolean {
    if (reading < 10) {
      return true;
    }
    if (reading % 10 <= Math.floor(reading / 10) % 10) {
      return false;
    }
    return this.isAscending(Math.floor(reading / 10));
  }
}
